const mapDBModelAlbum = ({ id, name, year }) => ({
    id,
    name,
    year
});

module.exports = { mapDBModelAlbum }